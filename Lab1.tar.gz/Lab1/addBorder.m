function borderedImage = addBorder(image, angle)

    [mdim, ndim] = size(image);
    
    horSize = ceil(ndim * cos(angle) * sin(angle));
    verSize = ceil(mdim * cos(angle) * sin(angle));
    horSize
    
    horBor = ones(horSize, mdim);
    verBor = ones(ndim, verSize);
    corBor = ones(horSize, verSize);
    
    borderedImage = [corBor, horBor, corBor;
                     verBor, image,  verBor;
                     corBor, horBor, corBor];
    return;


end
