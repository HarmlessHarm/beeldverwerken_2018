function color = nearest(image, x, y)

    color = image(round(x), round(y));
    return;
end