function rotatedImage = rotateImage(image, angle, method)

image = addBorder(image, angle);
% Create the necessary rotation matrix
invR = [cos(-angle), -sin(-angle);sin(-angle), cos(-angle)];

% Obtain indices needed for interpolation
[Mdim, Ndim] = size(image);
centerImage = [round(Mdim/2);round(Ndim/2)];

M = reshape(repmat((1:Ndim), Mdim, 1), 1, Mdim * Ndim);
N = repmat((1:Mdim), 1, Mdim);
% Z = ones(1, xdim*ydim);

coords = [M ; N];
% t = [0;Ndim * cos(angle)];
% t = [100;0];
% Obtain colors for the whole rotatedImage matrix
rotated = invR * (coords - centerImage) + centerImage;
% using the specified interpolation method
rotated(1,:);
subplot(1,2, 1);
imshow(image);
values = pixelValue(image, rotated(1,:), rotated(2,:), method);
size(values)
rotatedImage = reshape(values, Mdim, Ndim);
size(rotatedImage)
subplot(1,2,2);
imshow(rotatedImage)
%accumarray(X, Y, values, [ydim, xdim]);
end