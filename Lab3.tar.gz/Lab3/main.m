shap = im2double(rgb2gray(imread('attachments/shapes.png')));
box = im2double(rgb2gray(imread('attachments/box.png')));
bill = im2double(rgb2gray(imread('attachments/billboard.png')));
szel = im2double(rgb2gray(imread('attachments/szeliski.png')));


%% 2: Finding Lines using the Hough Transform


thresh_min = 0.2;
thresh_max = 0.6;
ntheta = 200;
nrho = 200;


[h, coords] = hough(shap, [thresh_min, thresh_max], nrho, ntheta);
e = edge(shap, 'Canny', [thresh_min, thresh_max]);

figure(1);
subplot(2,3,1);
imshow(shap);
subplot(2,3,2);
imshow(e);
subplot(2,3,3);
imshow(h,[])

[h, coords] = hough(szel, [thresh_min, thresh_max], nrho, ntheta);
e = edge(szel, 'Canny', [thresh_min, thresh_max]);

figure(1);
subplot(2,3,4);
imshow(szel);
subplot(2,3,5);
imshow(e);
subplot(2,3,6);
imshow(h, [])


%% 3: Finding the Lines as Local Maxima

figure(2)

% subplot(2,1,1)
lines = houghlines(szel, h, 180);
title('Opdracht 3')

%% 5: Optimal Line Estimation

epsilon = 10;
figure()
imshow(szel)
line_points = points_of_line(coords, lines(3,:), epsilon);
size(line_points)

hold on
plot(line_points(:, 1), line_points(:, 2), '*')
line_through_points(line_points);
hold off

% for i = 1:length(lines)
%    line_points = points_of_line(coords, lines(i,:), epsilon);
%    new_line = line_through_points(line_points)
% %    hold on
% %    plot(new_line(
% end


%% 6: 